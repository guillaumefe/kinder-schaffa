"use strict";

const express = require("express");
const axios = require("axios");
const crypto = require("crypto");

const app = express();
app.disable("x-powered-by");

/* =========================
   CONFIG
========================= */
const WIKI_LANG = "fr";
const USER_AGENT = "KinderSchaffa/1.6 (educational)";

const KEYWORD_GROUPS = [
  ["travail", "travailleur", "travailleurs"],     // groupe TRAVAIL
  ["enfant", "enfants", "mineur", "mineurs"],     // groupe ENFANT
];

const COMPANY_PAREN_MARKERS = [
  "societe",
  "société",
  "entreprise",
  "compagnie",
  "groupe",
  "marque",
  "organisation",
  "firme",
  "editeur",
  "éditeur",
];

const HOMONYMY_MARKERS = [
  "page d'homonymie",
  "page d’homonymie",
  "cette page d'homonymie",
  "cette page d’homonymie",
];

const NO_ARTICLE_MARKERS = [
  "wikipedia ne possede pas d'article avec ce nom",
  "wikipedia ne possède pas d'article avec ce nom",
  "wikipedia ne possede pas d’article avec ce nom",
  "wikipedia ne possède pas d’article avec ce nom",
  "wikipedia ne possede pas encore d'article avec ce nom",
  "wikipedia ne possède pas encore d'article avec ce nom",
  "aucun article ne correspond a ce titre",
  "aucun article ne correspond à ce titre",
  "la page demandee n'existe pas",
  "la page demandée n'existe pas",
];

// Ton GitHub Pages (Origin ne contient pas le path)
const STRICT_ORIGIN = "https://guillaumefe.github.io";

// Optionnel: définir ALLOWED_ORIGINS dans l'env (liste CSV)
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

const API_TOKEN = (process.env.API_TOKEN || "").trim();
if (!API_TOKEN) {
  console.warn("⚠️ API_TOKEN manquant: l'API refusera /_auth, /health et /check.");
}

function allowedOriginsList() {
  return ALLOWED_ORIGINS.length ? ALLOWED_ORIGINS : [STRICT_ORIGIN];
}

/* =========================
   Sécurité headers (API JSON)
========================= */
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader(
    "Strict-Transport-Security",
    "max-age=31536000; includeSubDomains; preload"
  );
  next();
});

/* =========================
   Auth Bearer (stateless)
   + exige Origin (bloque curl/CLI “simples”)
========================= */
function timingSafeEqualStr(a, b) {
  const ab = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ab.length !== bb.length) return false;
  return crypto.timingSafeEqual(ab, bb);
}

function extractBearer(req) {
  const auth = (req.headers.authorization || "").toString();
  const m = auth.match(/^Bearer\s+(.+)$/i);
  if (!m) return null;
  return m[1].trim();
}

function enforceOrigin(req) {
  const origin = req.headers.origin;

  // Exiger Origin pour éviter l’accès “facile” via CLI
  if (!origin) return { ok: false, code: 403, error: "Missing Origin" };

  const allowed = allowedOriginsList();
  if (!allowed.includes(origin)) {
    return { ok: false, code: 403, error: "Forbidden origin" };
  }
  return { ok: true };
}

function enforceBearer(req) {
  if (!API_TOKEN) {
    return {
      ok: false,
      code: 503,
      error: "Server not configured (API_TOKEN missing)",
    };
  }

  const token = extractBearer(req);
  if (!token) return { ok: false, code: 401, error: "Missing Bearer token" };

  if (!timingSafeEqualStr(token, API_TOKEN)) {
    return { ok: false, code: 401, error: "Invalid token" };
  }
  return { ok: true };
}

function requireBearer(req, res, next) {
  const o = enforceOrigin(req);
  if (!o.ok) return res.status(o.code).json({ ok: false, error: o.error });

  const a = enforceBearer(req);
  if (!a.ok) return res.status(a.code).json({ ok: false, error: a.error });

  return next();
}

/* =========================
   Endpoint interne pour Nginx auth_request: GET /_auth
   - Renvoie 200 si OK, sinon 401/403/503
   - Réponse courte (pas de JSON obligatoire)
========================= */
app.get("/_auth", (req, res) => {
  const o = enforceOrigin(req);
  if (!o.ok) return res.status(o.code).type("text/plain").send(o.error);

  const a = enforceBearer(req);
  if (!a.ok) return res.status(a.code).type("text/plain").send(a.error);

  return res.status(200).type("text/plain").send("OK");
});

/* =========================
   Wikipedia client
========================= */
const wikiApi = axios.create({
  baseURL: `https://${WIKI_LANG}.wikipedia.org`,
  headers: { "User-Agent": USER_AGENT, Accept: "application/json" },
  timeout: 15000,
});

async function wikiGet(params) {
  return wikiApi.get("/w/api.php", { params });
}

/* =========================
   Helpers
========================= */
function normalize(s) {
  return (s || "")
    .toString()
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .replace(/\s+/g, " ")
    .trim();
}

function stripHtml(html) {
  return (html || "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function wikiSearchUrl(org) {
  return `https://${WIKI_LANG}.wikipedia.org/wiki/Special:Search?search=${encodeURIComponent(
    org
  )}`;
}

async function fetchUserVisiblePageText(url) {
  const res = await axios.get(url, {
    timeout: 15000,
    maxRedirects: 5,
    headers: { "User-Agent": USER_AGENT, Accept: "text/html" },
    responseType: "text",
    validateStatus: (s) => s >= 200 && s < 400,
  });

  return normalize(stripHtml(res.data || ""));
}

function isHomonymyUserVisible(textN) {
  return HOMONYMY_MARKERS.some((m) => textN.includes(normalize(m)));
}

function isNoArticleUserVisible(textN) {
  return NO_ARTICLE_MARKERS.some((m) => textN.includes(normalize(m)));
}

/* =========================
   Wiki: page resolution
========================= */
async function resolveTitleBySearch(q){
  const res = await wikiGet({
    action: "query",
    format: "json",
    list: "search",
    srsearch: q,
    srlimit: 1,
    srnamespace: 0,
  });
  return res.data?.query?.search?.[0]?.title || null;
}

async function getPageByTitle(inputTitle){
  async function fetchByTitle(t){
    const res = await wikiGet({
      action: "query",
      format: "json",
      titles: t,
      redirects: 1,
      prop: "info|extracts",
      inprop: "url",
      explaintext: 1,
      exintro: 1,
    });

    const pages = res.data?.query?.pages || {};
    const page = Object.values(pages)[0];
    if (!page || page.missing) return null;

    return {
      title: page.title,
      pageId: page.pageid,
      url: page.fullurl || `https://${WIKI_LANG}.wikipedia.org/?curid=${page.pageid}`,
      intro: (page.extract || "").trim(),
    };
  }

  // 1) On commence par Search (robuste à la casse + ponctuation)
  const best = await resolveTitleBySearch(inputTitle);
  if (best){
    const byBest = await fetchByTitle(best);
    if (byBest) return byBest;
  }

  // 2) fallback: essais simples
  const variants = [
    inputTitle,
    String(inputTitle).replace(/'/g, "’"),
    String(inputTitle).replace(/['’]/g, ""),
  ];

  for (const v of variants){
    const p = await fetchByTitle(v);
    if (p) return p;
  }

  return null;
}

/* =========================
   Homonymy candidates
========================= */
async function getDisambigLinks(pageId, limit = 250) {
  const res = await wikiGet({
    action: "query",
    format: "json",
    pageids: pageId,
    prop: "links",
    plnamespace: 0,
    pllimit: limit,
  });

  const page = res.data?.query?.pages?.[pageId];
  const links = page?.links || [];
  return links.map((l) => l.title).filter(Boolean);
}

function isCompanyDisambigCandidate(userOrg, candidateTitle) {
  const orgN = normalize(userOrg);
  const candN = normalize(candidateTitle);

  if (!candN.includes(orgN)) return false;

  const m = candN.match(/\(([^)]+)\)/);
  if (!m) return false;

  const insideParen = normalize(m[1]);
  return COMPANY_PAREN_MARKERS.some((k) => insideParen.includes(normalize(k)));
}

async function listCompanyCandidatesFromHomonymy(userOrg, homonymyPageId) {
  const titles = await getDisambigLinks(homonymyPageId);
  return titles.filter((t) => isCompanyDisambigCandidate(userOrg, t));
}

/* =========================
   Controversy extraction
========================= */
function isControversyHeading(line) {
  const h = normalize(line);
  return (
    h.includes("controverse") ||
    h.includes("polémique") ||
    h.includes("polemique") ||
    h.includes("scandale") ||
    h.includes("affaire") ||
    h.includes("accusation") ||
    h.includes("critique") ||
    h.includes("litige")
  );
}

async function getControversySection(pageId) {
  const secRes = await wikiGet({
    action: "parse",
    format: "json",
    pageid: pageId,
    prop: "sections",
    redirects: 1,
  });

  const sections = secRes.data?.parse?.sections || [];
  const target = sections.find((s) => isControversyHeading(s.line));
  if (!target) return null;

  const textRes = await wikiGet({
    action: "parse",
    format: "json",
    pageid: pageId,
    section: target.index,
    prop: "text",
    redirects: 1,
    disableeditsection: 1,
    disablelimitreport: 1,
  });

  const html = textRes.data?.parse?.text?.["*"] || "";
  const rawText = stripHtml(html);
  const cleanText = normalize(rawText);

  return {
    title: target.line,
    text: cleanText,
    rawExcerpt: rawText.slice(0, 900),
    excerptAroundMatch: buildExcerptAroundChildLabor(html),
  };
}

/* =========================
   Keyword check
========================= */
function escapeRegex(s){
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function hasAnyWord(textN, words){
  // mot entier avec frontières : évite "retravailler" etc.
  const r = new RegExp(`\\b(?:${words.map(escapeRegex).join("|")})\\b`, "i");
  return r.test(textN || "");
}

function firstWordMatchIndex(rawText, words){
  // retourne l'index du 1er match (mot entier), ou -1
  const r = new RegExp(`\\b(?:${words.map(escapeRegex).join("|")})\\b`, "i");
  const m = r.exec(rawText || "");
  return m ? m.index : -1;
}

function clipWindow(text, centerIndex, radius = 450){
  const s = String(text || "");
  if (!s) return "";

  let start = Math.max(0, centerIndex - radius);
  let end = Math.min(s.length, centerIndex + radius);

  // coupe plus joli : essaie d'aller au prochain espace
  if (start > 0){
    const prevSpace = s.lastIndexOf(" ", start);
    if (prevSpace > 0) start = prevSpace + 1;
  }
  if (end < s.length){
    const nextSpace = s.indexOf(" ", end);
    if (nextSpace > 0) end = nextSpace;
  }

  const prefix = start > 0 ? "… " : "";
  const suffix = end < s.length ? " …" : "";
  return prefix + s.slice(start, end).trim() + suffix;
}

function includesAnyWord(text, words){
  const r = new RegExp(`\\b(?:${words.map(escapeRegex).join("|")})\\b`, "i");
  return r.test(text || "");
}

function windowHasBothGroups(rawWindow){
  const n = normalize(rawWindow);
  return (
    includesAnyWord(n, KEYWORD_GROUPS[0]) &&
    includesAnyWord(n, KEYWORD_GROUPS[1])
  );
}

function buildExcerptAroundChildLabor(htmlText){
  const raw = stripHtml(htmlText);
  const rawN = normalize(raw);

  // si globalement pas les 2 groupes -> rien
  if (!keywordGroupsAllPresent(rawN)) return "";

  const WINDOW = 900;  // taille du morceau renvoyé
  const STEP   = 220;  // pas de balayage (plus petit => plus précis)

  for (let start = 0; start < raw.length; start += STEP){
    const chunk = raw.slice(start, start + WINDOW);
    if (windowHasBothGroups(chunk)){
      // on coupe sur mots via clipSpan
      return clipSpan(raw, start, start + WINDOW);
    }
  }

  // fallback : si on n’a pas trouvé de fenêtre (rare), renvoie span entre 1ers matches
  const idxWork  = firstWordMatchIndex(raw, KEYWORD_GROUPS[0]);
  const idxChild = firstWordMatchIndex(raw, KEYWORD_GROUPS[1]);
  if (idxWork < 0 || idxChild < 0) return "";

  const left = Math.min(idxWork, idxChild);
  const right = Math.max(idxWork, idxChild);
  return clipSpan(raw, left - 280, right + 280);
}

function clipSpan(text, startIndex, endIndex){
  const s = String(text || "");
  if (!s) return "";

  let start = Math.max(0, startIndex);
  let end = Math.min(s.length, endIndex);

  if (start > 0){
    const prevSpace = s.lastIndexOf(" ", start);
    if (prevSpace > 0) start = prevSpace + 1;
  }
  if (end < s.length){
    const nextSpace = s.indexOf(" ", end);
    if (nextSpace > 0) end = nextSpace;
  }

  const prefix = start > 0 ? "… " : "";
  const suffix = end < s.length ? " …" : "";
  return prefix + s.slice(start, end).trim() + suffix;
}

function keywordGroupsAllPresent(textN){
  return KEYWORD_GROUPS.every(group => hasAnyWord(textN, group));
}

function findMatchedKeywords(textN){
  const found = new Set();
  for (const group of KEYWORD_GROUPS){
    for (const w of group){
      if (hasAnyWord(textN, [w])) found.add(w);
    }
  }
  return [...found];
}

/* =========================
   HEALTH (protégé)
========================= */
app.get("/health", requireBearer, (req, res) => res.json({ ok: true }));

/* =========================
   API: /check (protégé)
========================= */
app.get("/check", requireBearer, async (req, res) => {
  const org = (req.query.org || "").toString().trim();
  const pick = (req.query.pick || "").toString().trim();

  if (!org) return res.status(400).json({ ok: false, error: "Paramètre org requis" });
  if (org.length > 120 || pick.length > 200) {
    return res.status(400).json({ ok: false, error: "Paramètres trop longs" });
  }

  try {
    if (pick) {
      const chosen = await getPageByTitle(pick);
      if (!chosen) {
        return res.json({
          ok: true,
          org,
          title: null,
          wikipedia: null,
          summary: null,
          childLabor: null,
          message: "Je ne sais pas : la page choisie n’existe pas.",
          homonymyDetected: true,
          needChoice: true,
        });
      }

      const visibleText = await fetchUserVisiblePageText(chosen.url);
      if (isNoArticleUserVisible(visibleText)) {
        return res.json({
          ok: true,
          org,
          title: null,
          wikipedia: null,
          summary: null,
          childLabor: null,
          message:
            "Je ne sais pas : Wikipédia ne possède pas d’article avec ce nom.",
          homonymyDetected: false,
          needChoice: false,
        });
      }

      const controversy = await getControversySection(chosen.pageId);

      if (!controversy) {
        return res.json({
          ok: true,
          lang: WIKI_LANG,
          org,
          title: chosen.title,
          wikipedia: chosen.url,
          homonymyDetected: false,
          needChoice: false,
          childLabor: false,
          matchedKeywords: [],
          summary: chosen.intro || "",
          summarySource: "intro",
          controversyTitle: null,
          message:
            "Aucune section 'Controverse' (ou assimilée) trouvée sur cette page.",
          searchedIn: "controversy-section-only",
        });
      }

      const all = keywordGroupsAllPresent(controversy.text);
      const matchedKeywords = findMatchedKeywords(controversy.text);

      return res.json({
        ok: true,
        lang: WIKI_LANG,
        org,
        title: chosen.title,
        wikipedia: chosen.url,
        homonymyDetected: false,
        needChoice: false,
        childLabor: all,
        matchedKeywords,
	excerptAroundMatch: all ? (controversy.excerptAroundMatch || "") : "",
        summary: all ? controversy.rawExcerpt : chosen.intro || "",
        summarySource: all ? "controversy" : "intro",
        controversyTitle: controversy.title,
        message: all
          ? "Des signaux ont été détectés dans la section Controverse."
          : "Aucun signal détecté dans la section Controverse.",
        searchedIn: "controversy-section-only",
      });
    }

    const initial = await getPageByTitle(org);

    if (!initial) {
      const searchUrl = wikiSearchUrl(org);
      const visibleText = await fetchUserVisiblePageText(searchUrl);

      if (isNoArticleUserVisible(visibleText)) {
        return res.json({
          ok: true,
          org,
          title: null,
          wikipedia: null,
          summary: null,
          childLabor: null,
          message:
            "Je ne sais pas : Wikipédia ne possède pas d’article avec ce nom.",
          homonymyDetected: false,
          needChoice: false,
        });
      }

      return res.json({
        ok: true,
        org,
        title: null,
        wikipedia: null,
        summary: null,
        childLabor: null,
        message:
          "Je ne sais pas : je ne trouve pas une page Wikipédia unique pour ce nom.",
        homonymyDetected: false,
        needChoice: false,
      });
    }

    const initialVisibleText = await fetchUserVisiblePageText(initial.url);

    if (isNoArticleUserVisible(initialVisibleText)) {
      return res.json({
        ok: true,
        org,
        title: null,
        wikipedia: null,
        summary: null,
        childLabor: null,
        message:
          "Je ne sais pas : Wikipédia ne possède pas d’article avec ce nom.",
        homonymyDetected: false,
        needChoice: false,
      });
    }

    const homonymyDetected = isHomonymyUserVisible(initialVisibleText);

    if (homonymyDetected) {
      const candidates = await listCompanyCandidatesFromHomonymy(org, initial.pageId);

      if (!candidates || candidates.length === 0) {
        return res.json({
          ok: true,
          org,
          title: null,
          wikipedia: null,
          summary: null,
          childLabor: null,
          homonymyDetected: true,
          needChoice: false,
          homonymyCandidates: [],
          message:
            "Je ne sais pas : page d’homonymie mais je ne trouve pas de candidat (entreprise/société).",
        });
      }

      return res.json({
        ok: true,
        org,
        title: null,
        wikipedia: null,
        summary: null,
        childLabor: null,
        homonymyDetected: true,
        needChoice: true,
        homonymyCandidates: candidates,
        message: "Choisis la bonne page (homonymie) :",
      });
    }

    const controversy = await getControversySection(initial.pageId);

    if (!controversy) {
      return res.json({
        ok: true,
        lang: WIKI_LANG,
        org,
        title: initial.title,
        wikipedia: initial.url,
        homonymyDetected: false,
        needChoice: false,
        childLabor: false,
        matchedKeywords: [],
        summary: initial.intro || "",
        summarySource: "intro",
        controversyTitle: null,
        message:
          "Aucune section 'Controverse' (ou assimilée) trouvée sur cette page.",
        searchedIn: "controversy-section-only",
      });
    }

    const all = keywordGroupsAllPresent(controversy.text);
    const matchedKeywords = findMatchedKeywords(controversy.text);

    return res.json({
      ok: true,
      lang: WIKI_LANG,
      org,
      title: initial.title,
      wikipedia: initial.url,
      homonymyDetected: false,
      needChoice: false,
      childLabor: all,
      matchedKeywords,
      excerptAroundMatch: all ? (controversy.excerptAroundMatch || "") : "",
      summary: all ? controversy.rawExcerpt : initial.intro || "",
      summarySource: all ? "controversy" : "intro",
      controversyTitle: controversy.title,
      message: all
        ? "Des signaux ont été détectés dans la section Controverse."
        : "Aucun signal détecté dans la section Controverse.",
      searchedIn: "controversy-section-only",
    });
  } catch (e) {
    return res.status(500).json({
      ok: false,
      error: "Erreur Wikipedia",
      details: e?.message || String(e),
    });
  }
});

/* =========================
   404 JSON
========================= */
app.use((req, res) => res.status(404).json({ ok: false, error: "Not found" }));

/* =========================
   START
========================= */
const PORT = Number(process.env.PORT || 3000);
app.listen(PORT, "0.0.0.0", () => {
  console.log(`🧸 Kinder Schaffa API sur http://localhost:${PORT}`);
  console.log("CORS autorisés:", allowedOriginsList().join(", "));
  console.log("Auth: Bearer + Origin requis sur /_auth, /health, /check");
});
